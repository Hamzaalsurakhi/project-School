﻿using Microsoft.AspNetCore.Mvc;
using School.Models;
using System.Data.SqlClient;

namespace School.Controllers
{
    public class StudentController : Controller
    {
        public IActionResult ListOfStudent(int StudentId, string StudentFirstName, string StudentLastName)
        {
            string connectionString= "Server=.;Database=DbSchool;User Id=sa;Password=123456;";
            #region Array
            //string[] students = new string[3];


            //students[0] = "Hamza";
            //students[1] = "Omar";
            //students[2] = "Hana";
            #endregion
            #region ObjectOfArray
            //Student[] students = new Student[3];
            //students[0] = new Student();
            //students[1] = new Student();
            //students[2] = new Student();

            //students[0].StudentId = 1;
            //students[0].StudentFirstName = "Hamza";
            //students[0].StudentLastName = "Alsahouri";

            //students[1].StudentId = 2;
            //students[1].StudentFirstName = "Zaid";
            //students[1].StudentLastName = "Alsahouri";

            //students[2] = new Student
            //{
            //    StudentId = 3,
            //    StudentFirstName = "Laith",
            //    StudentLastName = "Alsahouri"
            //};


            //ViewBag.students = students;
            #endregion
            #region List
            //if (StudentFirstName != null)

            //{
            //    students.Add(new Student
            //    {

            //        StudentId = StudentId,
            //        StudentFirstName = StudentFirstName,
            //        StudentLastName = StudentFirstName

            //    });
            //}

            //Student stu1 = new Student();
            //stu1.StudentFirstName = "Test";
            //students.Add(stu1);

            ////students.Add(new Student
            ////{
            ////    StudentId = 1,
            ////    StudentFirstName = "Hamza",
            ////    StudentLastName = "Alsahouri"

            ////});
            ////students.Add(new Student
            ////{
            ////    StudentId = 2,
            ////    StudentFirstName = "Laith",
            ////    StudentLastName = "Alsahouri"

            ////});
            ////students.Add(new Student
            ////{
            ////    StudentId = 3,
            ////    StudentFirstName = "Zaid",
            ////    StudentLastName = "Alsahouri"

            ////});

            ////students.Add(new Student
            ////{
            ////    StudentId = 4,
            ////    StudentFirstName = "Zaid",
            ////    StudentLastName = "Alsahouri"

            ////});
            #endregion


            List<Student> students = new List<Student>();

            SqlConnection connection = new SqlConnection(connectionString);

            string Query = "select* from Students";

            SqlCommand command = new SqlCommand(Query, connection);

            
           
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    students.Add(new Student()
                    {
                       StudentId = (int)reader["StudentId"],
                   StudentFirstName  = (string)reader["FirstName"],
                    StudentLastName = (string)reader["LastName"]
                });
                               
                               
                }
                reader.Close();
               connection.Close();
            

            ViewBag.student = students;





            return View();
        }
        public IActionResult Add()
        {
            return View();
        }

        public IActionResult Create(int StudentId,string StudentFirstName, string StudentLastName)
        {
            string connectionString = "Server=.;Database=DbSchool;User Id=sa;Password=123456;";
            SqlConnection connection = new SqlConnection(connectionString);

            string Query = @"Insert INTO Students(FirstName,LastName)
                Values(@FirstName,@LastName)";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@FirstName", StudentFirstName);
            command.Parameters.AddWithValue("@LastName", StudentLastName);


            connection.Open();

            command.ExecuteNonQuery();
            connection.Close();

            return RedirectToAction("ListOfStudent", new {StudentId=StudentId,StudentFirstName=StudentFirstName,StudentLastName=StudentLastName});//HTTP REQUEST 
        }
    }
}
