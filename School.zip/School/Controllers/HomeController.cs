using Microsoft.AspNetCore.Mvc;
using School.Models;
using System.Diagnostics;

namespace School.Controllers
{
    public class HomeController : Controller
    {
      

        public IActionResult Index(string Hamza)
        {
            return View();
        }

        public IActionResult Privacy()
        {
           
            return View();

        }

       public IActionResult Test()
        {
            return View();
            //HTML Page (Views - > Home -> Index.html (action)
        }
    }
}
