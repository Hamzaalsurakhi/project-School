﻿namespace School.Models
{
    public class Student
    {
        public int StudentId;

        public string StudentFirstName;

        public string StudentLastName;
    }
}
